// var firebase = require('firebase');
// var config =  {
//     apiKey: "AIzaSyALwIRzd8-0tACUGay3xa0gaT6dXoED8yQ",
//     authDomain: "opensearch-2a0db.firebaseapp.com",
//     databaseURL: "https://opensearch-2a0db.firebaseio.com",
//     projectId: "opensearch-2a0db",
//     storageBucket: "opensearch-2a0db.appspot.com",
//     messagingSenderId: "710024249927"
//   };
// firebase.initializeApp(config);
// firebase.auth().signInWithEmailAndPassword('vasudevan.palani@gmail.com', 'password').catch(function(error){
//     console.log("ij error",error);
// }).then(user => {
//   firebase.auth().currentUser.getIdToken(true).then( token => {
//     console.log(token);
//   })
//   .catch(err => {
//     console.log(err);
//   })
// });


var stripe = require("stripe")(
  "sk_test_P4GXFh6a1i97ieWLSKpYsdt4"
);


stripe.accounts.list(
  { limit: 3 },
  function(err, accounts) {
    console.log(accounts);
    accounts.data.forEach(account=>{
      stripe.accounts.del(account.id,function(err,con){
        console.log(con);
      });
    })
  }
);
